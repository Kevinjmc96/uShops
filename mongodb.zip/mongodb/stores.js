const mongoose = require('mongoose');
mongoose.set('useFindAndModify', false);

var StoresSchema = mongoose.Schema ({
	codigoUnico: String,
	fechaCreacion: { type: Date, default: Date.now },
	fechaFinalizacion: { type: Date, default: Date.now },
	habilitacionVentas: Boolean,
	link: String,
	departamento: String,
	nombreEmpresa: String,
	mision: String,
	areaPrincipal: String,
	ubicacion: String,
	direccion: String,
	telefonos: [String],
	imagenURL: [
		{
			_id: false,
			URL: String,
			nombreInterno: String,
			nombreExterior: String,
			tipo: String,
			fechaCreacion: { type: Date, default: Date.now }
		} ]
});


module.exports = mongoose.model('model2', StoresSchema, 'stores');
 