const mongoose = require('mongoose');
mongoose.set('useFindAndModify', false);

var CategoriasSchema = new mongoose.Schema ({
  codigoUnico: String,
  categoriaGeneral: String,
  prioridad: String,
  titulo: String,
  subtitulo: String,
  imagen: [ 
    {
      _id: false,
      URL: String,
      nombreInterno: String,
      nombreExterior: String,
      tipo: String,
      fechaCreacion: { type: Date, default: Date.now } 
    } ]
});


module.exports  = mongoose.model('model1', CategoriasSchema, 'categories');