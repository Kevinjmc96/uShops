'use strict'

const jwt = require('jsonwebtoken');
var conexion;

module.exports={

    JWT_SECRET:'xLoxOhuIcYBTzOWYGctsCFnU9gA6SUW5XELkdKzYn6Do0F7sOIhzCU2hR9X2ozr',

    getDB:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).db;
    },
    getPort:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).port;
    },
    getUsername:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).user;
    },
    getHabilitaciones:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).habilitaciones;
    },
    getToken:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return token;
    },

    setConexion:function(conection){
        conexion = conection;
        return;
    },
    getConexion:function() {
        return conexion;
    },
    getAdminDatabase:function(){
        return 'AdministracionUshops'
    },
    getDatabase:function(){
        return 'UshopsDatabase'
    }

};
