'use strict'


var db = require('./db');
var global = require('./global');
var Notificacion = require('./models/notificacion');
const ObjectID = require('mongodb').ObjectID;


db.connect('mongodb://dbClickAdmin:clickAdminPass@52.43.113.195:38510/admin', function(err) {

    if (err) {
        return console.log(err)
    } else {
        console.log("La base de datos se conecta correctamente");


        //aprobacioProducto();
        //correccionProducto();
        //bienvenida();
        ordenesCarrito();



        // notificacion no valida... error de proceso
        // envioCodigoValidacion();  
    }
})




///////////////////////////////////////// notificaciones  aprobacion de producto  //////////////////////////////

function aprobacioProducto(){
    var database = db.get();
    var collection = database.db(global.getDatabase()).collection('products');

    const pipeline = [
        {
            $match: 
            {  "updateDescription.updatedFields.estadoPublicacion": 'publicado',
        }
        }
    ]

    // {operationType: 'update'},
    collection.watch(pipeline).on('change', documento=>{

        console.log(documento);
        console.log('//////////////////// aprobacion de producto //////////////////');

        busquedaDocumento(documento.documentKey._id, 'products').then(resultDocument=>{
            let auxNotificacion={
                empresa : resultDocument.identificadorEmpresa, 
                usuario : null, 
                tipo : 'aprobacion producto', 
                imagen : 'https://s3-us-west-2.amazonaws.com/img.ushops/logo-01.jpg', 
                titulo : 'PRODUCTO APROBADO', 
                mensaje : 'Un administrador aprobó tu producto '+ resultDocument.nombreProducto,
                parametrosAdicionales : {
                    identificadorProducto: resultDocument.identificadorProducto
                }
    
            }

            creacionNotificacion(auxNotificacion).then(result=>{
                console.log(result)
            }, error =>{
                console.log(error)
            })
        })
    })
}


///////////////////////////////////////// notificaciones  correccion de producto  //////////////////////////////

function correccionProducto(){
    var database = db.get();
    var collection = database.db(global.getDatabase()).collection('products');

    const pipeline = [
        {
            $match: 
            {  "updateDescription.updatedFields.estadoPublicacion": 'en correccion',
        }
        }
    ]

    collection.watch(pipeline).on('change', documento=>{

        console.log(documento);
        console.log('//////////////////// correccion de producto //////////////////');

        busquedaDocumento(documento.documentKey._id, 'products').then(resultDocument=>{
            let auxNotificacion={
                empresa : resultDocument.identificadorEmpresa, 
                usuario : null, 
                tipo : 'correccion producto', 
                imagen : 'https://s3-us-west-2.amazonaws.com/img.ushops/logo-01.jpg', 
                titulo : 'PRODUCTO EN CORRECCION', 
                mensaje : 'Un administrador te envió una recomendación de tu producto '+ resultDocument.nombreProducto,
                parametrosAdicionales : {
                    identificadorProducto: resultDocument.identificadorProducto
                }
    
            }

            creacionNotificacion(auxNotificacion).then(result=>{
                console.log(result)
            }, error =>{
                console.log(error)
            })
        })
    })
}


///////////////////////////////////////// notificaciones ordenes de compra  //////////////////////////////

function ordenesCarrito(){

    var collection =  db.get().db(global.getDatabase()).collection('ordenesCompra');

    const pipeline = [
        {
            $match: 
            //{  "updateDescription.updatedFields.validacion": 'validado'}
            {operationType: 'insert'}
        }
    ]


    collection.watch(pipeline).on('change', documento=>{

        let promesaGeneral = new Promise((resolve,reject) => {resolve ('start')})
        promesaGeneral.then(
            result =>{
/////////////////////////////////ELEGIR LA BASE EN LA QUE SE VA A BUSCAR                                                  
               return creacionNotificacionUsuario (documento.fullDocument)
             },error=>{
                return  new Promise.reject(error)
             }
        )
        .then(
           carrito =>{
/////////////////////////////////INFORMACION DEL PRODUCTO                                              
                return inf_products(carrito)
             },error=>{
                return  new Promise.reject(error)
             }
        )  
        .then(            
            inf_prodct =>{                                                   
/////////////////////////////////INFORMACION DE LA TIENDA
                return inf_stores (inf_prodct)
             },error=>{
                return  Promise.reject(error)
             }
        )
        .then(            
            inf_str =>{    
                console.log('////////////////////////////////////////////')
                console.log(inf_str)                                                 
/////////////////////////////////NOTIFICACION A LAS TIENDAS
                return creacionNotificacionTienda (inf_str)
             },error=>{
                return  Promise.reject(error)
             }
        )
    })
}




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
async function creacionNotificacionUsuario(parametros){

    let fechaActual = new Date();
    fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );

    let identificador = 'N'+await generadorNumeroRandom(12);

    let collection =  db.get().db(global.getDatabase()).collection('notificaciones');

    let auxNotificacion = new Notificacion();
    auxNotificacion.setParameters('fechaCreacion',fechaActual);
    auxNotificacion.setParameters('identificadorEmpresa', '');
    auxNotificacion.setParameters('identificadorUsuario', parametros.identificadorUsuario);
    auxNotificacion.setParameters('identificadorNotificacion', identificador);

    auxNotificacion.setParameters('titulo', 'COMPRA REALIZADA');
    auxNotificacion.setParameters('mensaje', 'Compra realizada con exito');
    auxNotificacion.setParameters('prioridad', '');
    auxNotificacion.setParameters('tipo', 'compra carrito');
    auxNotificacion.setParameters('imagen', {URL: "https://s3-us-west-2.amazonaws.com/img.ushops/logo-01.jpg"});

    auxNotificacion.setParameters('estadoNotificacion', 'pendiente');
    auxNotificacion.setParameters('parametrosAdicionales', {carrito: parametros.carrito });


    var promesa = new Promise((resolve, reject) => {

    collection.insertOne( auxNotificacion,(err)=>{
            if(err){
                reject ({message:"Error en la creación de la notificacion"});
            }else{
                let aux = [parametros.carrito, parametros.datosFacturacion.nombre ]
                resolve (aux);
            }
        }
    )
    });
    return promesa;
}

async function inf_products(datos){
    let carrito= datos[0];
    let nombre= {nombreComprador: datos[1]}; 

    let fechaActual = new Date();
    fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );
        
    let DB = db.get().db(global.getDatabase()).collection('products');
    let filtro = {projection:{ _id: 0, identificadorEmpresa:1, nombreProducto:1}};
    
    var inf_usuarios = await Promise.all(carrito.map(                
        
        function(result) {
            return new Promise((resolve, reject) => {                    
                let One ={identificadorProducto: result.identificadorProducto};   
                DB.find(One, filtro).toArray(function (err,prdct_inf) {
                    if(err){ 
                        reject(err) 
                    }else{
                        let aux = Object.assign(nombre,prdct_inf[0]);
                        resolve (aux);    
                    }
                })
            })
        }))
    
    return(inf_usuarios)
}

async function inf_stores(datos){
    
    let DB = db.get().db(global.getDatabase()).collection('stores');
    let filtro = {projection:{ _id: 0, identificadorUsuario:1}};
    
    var inf_usuarios = await Promise.all(datos.map(                
        
        function(result) {
            return new Promise((resolve, reject) => {                    
                let One ={identificador: result.identificadorEmpresa};   
                DB.find(One, filtro).toArray(function (err,str_inf) {
                    if(err){ 
                        reject(err) 
                    }else{
                        let aux = Object.assign(datos[0],str_inf[0]);
                        resolve (aux);    
                    }
                })
            })
        }))
    
    return(inf_usuarios)
}

async function creacionNotificacionTienda(parametros){

    var inf_usuarios = await Promise.all(parametros.map(                
        
        async function(result) {
            
            let fechaActual = new Date();
            fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );

            let identificador = 'N'+await generadorNumeroRandom(12);

            let collection =  db.get().db(global.getDatabase()).collection('notificaciones');

            let auxNotificacion = new Notificacion();
            auxNotificacion.setParameters('fechaCreacion',fechaActual);
            auxNotificacion.setParameters('identificadorEmpresa', result.identificadorEmpresa);
            auxNotificacion.setParameters('identificadorUsuario', result.identificadorUsuario);
            auxNotificacion.setParameters('identificadorNotificacion', identificador);

            auxNotificacion.setParameters('titulo', 'COMPRA REALIZADA');
            auxNotificacion.setParameters('mensaje', ''+result.nombreComprador+' realizó una compra en tu tienda');
            auxNotificacion.setParameters('prioridad', '');
            auxNotificacion.setParameters('tipo', 'compra carrito');
            auxNotificacion.setParameters('imagen', {URL: "https://s3-us-west-2.amazonaws.com/img.ushops/logo-01.jpg"});

            auxNotificacion.setParameters('estadoNotificacion', 'pendiente');
            auxNotificacion.setParameters('parametrosAdicionales', {});

            var promesa = new Promise((resolve, reject) => {

                collection.insertOne( auxNotificacion,(err)=>{
                        if(err){
                            reject ({message:"Error en la creación de la notificacion"});
                        }else{
                            resolve (auxNotificacion);
                        }
                    }
                )
                });
                return promesa;


        }))
    
    return(inf_usuarios)

    

}

function generadorNumeroRandom (digitos){
        let caracteres = "0123456789";
        let identificador = "";
        let i;
        for (i=0; i<digitos; i++) identificador +=caracteres.charAt(Math.floor(Math.random()*caracteres.length));
    
        return identificador;
}
    
    