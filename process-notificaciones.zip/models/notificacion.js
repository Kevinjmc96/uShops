

var ObjectID = require('mongodb').ObjectID;

function Product (){

        this._id = null,
        this.identificadorEmpresa = null,
        this.identificadorUsuario = null,
        this.identificadorNotificacion = null,
        this.fechaCreacion =  null,

        this.imagen = {
            URL: 'https://s3-us-west-2.amazonaws.com/img.ushops/logo-01.jpg'
        },

        this.titulo = "",
        this.mensaje = "",

        this.prioridad =  '',
        this.tipo =  '',    
        this.estadoNotificacion =  '',
        this.parametrosAdicionales =  {},

    // seteos y cambios de datos y parametros de factura standard
    this.setParameters= function (parametro, variable) {
        if(variable!==null && variable !== undefined)
            switch (parametro)
            {
                case 'fechaCreacion':
                    this.fechaCreacion =  variable;
                    break;
                case 'identificadorEmpresa':
                    this.identificadorEmpresa = variable;
                    break;
                case 'identificadorUsuario':
                    this.identificadorUsuario = variable;
                    break;
                case 'identificadorNotificacion':
                    this.identificadorNotificacion = variable;
                    break;
                case 'titulo':
                    this.titulo = variable;
                    break;
                case 'mensaje':
                    this.mensaje = variable;
                    break;
                case 'prioridad':
                    this.prioridad = variable;
                    break;
                case 'tipo':
                    this.tipo = variable;
                    break;
                case 'estadoNotificacion':
                    this.estadoNotificacion = variable;
                    break;
                case 'imagen':
                    this.imagen.URL = variable;
                    break;
                case 'parametrosAdicionales':
                    this.parametrosAdicionales = variable;
                    break;

            }
    };
    // this.addImage = function (imagenes) {
    //         console.log(imagenes);

    //         this.images.push(imagenes);

    // }
}

module.exports = Product;

