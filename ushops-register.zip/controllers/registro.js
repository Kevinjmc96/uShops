'use strict'

var verificacionCedula = require('./funciones/verificacion_cedula');
// var FacturaElectronica = require('../models/facturaElectronica');
var mod_auth = require('../middleware/moduleAuthorization');
var global = require('../global');
var db = require('../db');
const ObjectID = require('mongodb').ObjectID;
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fetch = require('node-fetch');

function status (req,res) {

    return res.status(200).send('controlador registro OK');
}

function administracionRegistro (req, res){
    let user = req.body;
    console.log(user);


    // verificacion de parametros en mensaje
    if (req.body.device=== undefined || req.body.nombre=== undefined || req.body.email=== undefined || req.body.scope=== undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    // if (req.body.cedula=== undefined  && req.body.username=== undefined ) {
    if (req.body.username=== undefined || req.body.telefono=== undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    if (req.body.password=== undefined) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    // if (req.body.device === 'web' || req.body.device === 'tablet') {
        if (req.body.email=== undefined) {
            return res.status(500).send({message: "falta parametro de usuario"});
        }
    // }
    
    _busquedaEmpresa(req.body.scope).then(
        resultEmpresa => {

            // verificacionCedula.verificacion_cedula(req.body.cedula).then(
            //     result => {
                    // console.log(result);
        
                    let busqueda;
        
                    busqueda = req.body.email;
                    console.log('busqueda', busqueda);
                
                    _busquedaUsuario(busqueda).then(result => {
                
                        // si esta libre o en proceso ingresa aqui
                        console.log('ok', result);
                
                        if (result === null) {
                            creacion_cuenta(req, res, resultEmpresa.scope);
                        } else {
                            // creacion de cuentas
                            // si estado esta en validado se encuentra validada la cuenta
                            if(result.validacion === 'validado' ) {
                
                                return res.status(202).send({mensaje:'cuenta ya validada'});
                            }
                            // si estado esta en pendiente debe enviarse el metodo de confirmacion
                            // if(result.validacion === 'pendiente' ) {
                
                            return res.status(202).send({mensaje:'cuenta encontrada pendiente de validacion'});
                        }
                
                    }, reason => {
                        // si el usuario ya esta registrado entrega el error
                        console.log('error', reason);
                        return res.status(500).send({mensaje:'error en busqueda'});
                    });
        
                // },
                // error => {
                //     return res.status(501).send({mensaje:'error en cedula'});
        
                //     console.log(error);
        
                // }
            // )

        }, error => {
            return res.status(500).send({message: "error de negocio"});
        }
    )

    // 
    


    // if (){


    // } else {
    //     return res.status(500).send({message: "falta parametro de usuario"});
    // }





    
}

async function creacion_cuenta (req, res, empresa){

    // let cedula = req.body.cedula;
    // let nombre = req.body.nombre;
    // let telefono = req.body.telefono;
    //
    // console.log(cedula, nombre, telefono);
    //

    let identificador_encontrado = false;
    let identificador;
    let i;
    for (i =0 ; i< 25; i++) {
        identificador = await ('USH'+generadorNumeroRandom(7) + 'D');
        //  identificador = 'U5465656D';
        console.log('identificador', identificador);
        let resp = await _busquedaIdentificadorLibre(identificador);


        if (resp === 'free'){
            identificador_encontrado = true;
        }
        if(identificador_encontrado === true ) {
            break;
        }
    }
    console.log(identificador_encontrado);

    if(identificador_encontrado === true) {
        // creacion del registro de usuario

        creacionUsuario(identificador, req, res, empresa);

    } else {
        return res.status(500).send({mensaje: 'error no hay identificadores disponibles'});
    }
}

async function creacionUsuario(identificador,  req, res , empresa) {


    let username = null;
    let password = null;
    // if(req.body.username !== undefined){
        username = req.body.username;
        password = req.body.password;
    // }


    const fechaActual = new Date();
    fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );
    const codigoVerificacion = await (generadorNumeroRandom(5));
    const claveCifrada = await generadorClave(password);

    let identificadorEmpresa = await ('E1'+generadorNumeroRandom(7) + 'U');



    let usuario = {
        identificador : identificador,
        username : username,
        email: req.body.email,
        nombreCompleto: req.body.nombre,
        telefono: req.body.telefono,
        fechaCreacion: fechaActual,
        codigoVerificacion: codigoVerificacion,
        validacion: 'pendiente',
        estado: "creacion",
        empresaRegistradora: empresa,
        identificadorEmpresa: identificadorEmpresa,
        habilitacion: 'habilitado',
        nombreEmpresa: null,
        accesos: []
    };

    // if (username !== null){
        // usuario.username = username;
    // }


    if (req.body.device === 'web' ){
        usuario.password=  claveCifrada;
        // usuario.passwordRapida=  claveCifrada;

    } else if (req.body.device === 'tablet') {
        usuario.password=  claveCifrada;
        // usuario.passwordRapida=  claveCifrada;

    } else if (req.body.device === 'movil') {
        usuario.password=  claveCifrada;
        // usuario.passwordRapida=  claveCifrada;

    } else {
        return res.status(500).send({mensaje: "Error en parametros de device"});
    }

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

   collection.insertOne(
        usuario,
        (err) => {
            if (err) {
                return res.status(500).send({mensaje: "Error en la creación del usuario"});
            } else {
                //////////////////////////////////////////////////envio de mensajes ///////////////////////////////

        
                enviocodigoValidacion({identificadorUsuario: usuario.identificador, scope:  empresa,fechaCreacion: fechaActual});

                return res.status(200).send({mensaje: 'usuario creado', codigoVerificacion: codigoVerificacion});
            }
        }
    );


}

function enviocodigoValidacion(usuario){
    console.log('usuario',usuario);

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('codigosValidacion');

    collection.insertOne(
        usuario,
        (err) => {
            if (err) {
               console.log(err);
            } else {
                //////////////////////////////////////////////////envio de mensajes ///////////////////////////////
                console.log('envio codigo',usuario);
                // return res.status(200).send({mensaje: 'envio de codigos', codigoVerificacion: codigoVerificacion});
            }
        }
    );
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
function getVerifCode (req, res){
    let user = req.body;
    console.log(user);


    // verificacion de parametros en mensaje
    if ((req.body.username=== undefined) || req.body.device=== undefined  || req.body.scope=== undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    let busqueda ;

    busqueda = req.body.username;
    console.log('busqueda', busqueda);
        
    _busquedaEmpresa(req.body.scope).then(
        resultEmpresa => {
        _busquedaUsuario(busqueda).then(async resultUsuario => {
            // si esta libre o en proceso ingresa aqui
            console.log('result', resultUsuario);

            if(resultUsuario.validacion === 'validado'||resultUsuario.validacion === 'creacion' ) {
                return res.status(500).send({mensaje:'cuenta validada previamente'});
            }

            const codigoVerificacion = await (generadorNumeroRandom(5));
            const claveCifrada = await generadorClave(codigoVerificacion);

            let auxActualizacion = {codigoVerificacion: codigoVerificacion};

            // if (req.body.device === 'web'){
            //     auxActualizacion.password=  claveCifrada;
            //     auxActualizacion.passwordRapida=  claveCifrada;

            // } else if (req.body.device === 'tablet') {
            //     auxActualizacion.password=  claveCifrada;
            //     auxActualizacion.passwordRapida=  claveCifrada;

            // } else if (req.body.device === 'movil') {
            //     auxActualizacion.password=  claveCifrada;
            //     auxActualizacion.passwordRapida=  claveCifrada;

            // } else {
            //     return res.status(500).send({mensaje: "Error en parametros de device"});
            // }

            // auxActualizacion.estado = 'cambio contraseña';
            // auxActualizacion.estado = 'envio codigo';

            var database = db.get();
            var DB = database.db(global.getAuthDatabase());
            var collection = DB.collection('usuarios');

            collection.findOneAndUpdate(
                {_id: new ObjectID(resultUsuario._id)},
                {$set:auxActualizacion},
                (err,result)=> {
                    if (err) {
                        return res.status(500).json({error: err.message});
                    }
                    if (!result.value) {
                        return res.status(404).json({error: 'no actualizado'});
                    }
                    const fechaActual = new Date();
                    fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );
                
                    enviocodigoValidacion({identificadorUsuario: resultUsuario.identificador, scope:  resultEmpresa.scope, fechaCreacion: fechaActual});
                    return res.status(200).send({codigoVerificacion: codigoVerificacion});
                });
                // }
            // });


        }, reason => { 
            // si el usuario ya esta registrado entrega el error
            console.log('error', reason);
            return res.status(500).send({mensaje:'error en busqueda'});
        });
    }, error=>{
        return res.status(500).send({mensaje:'error de negocio'});

    });
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
function verificacionRegistro (req, res){
    let user = req.body;
    console.log(user);

    // verificacion de parametros en mensaje
    if ((req.body.username=== undefined) || req.body.scope=== undefined || req.body.codigoVerificacion === undefined) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    let busqueda ;

    busqueda = req.body.username;
    console.log('busqueda', busqueda);

      
    _busquedaEmpresa(req.body.scope).then(
        resultEmpresa => {

        _busquedaUsuario(busqueda).then(async result => {
            // si esta libre o en proceso ingresa aqui
            console.log('result', result);
            if(result === null ) {
                return res.status(500).send({mensaje:'cuenta inexistente'});
            }
            if(result.validacion === 'pendiente') {
                // validacion primera vez cuenta
                console.log(result.codigoVerificacion , req.body.codigoVerificacion);
                if (result.codigoVerificacion === req.body.codigoVerificacion) {

                    let actualizacionCuenta = {
                        // validacion: 'validado',
                        validacion: 'validado',
                        // estado: "habilitado",
                        estado: "habilitado",     /// requiere cambio de contraseña
                        accesos: []
                    } ;
                    // const claveCifrada = await generadorClave(result.codigoVerificacion);

                    // if (req.body.device === 'web'){
                    //     actualizacionCuenta.password= claveCifrada;
                    //     actualizacionCuenta.passwordRapida= claveCifrada;
                    // }else if(req.body.device === 'tablet') {
                    //     actualizacionCuenta.password= claveCifrada;
                    //     actualizacionCuenta.passwordRapida= claveCifrada;
                    // } else if (req.body.device === 'movil') {
                    //     actualizacionCuenta.passwordRapida= claveCifrada;
                    //     actualizacionCuenta.password= claveCifrada;
                    // } else {
                    //     return res.status(500).send({mensaje:'error en device'});
                    // }
                    actualizacionCuenta.accesos.push({
                        scope: resultEmpresa.scope,
                        habilitacionGeneral: "habilitado",
                        habilitaciones:  [],
                        permisoInformacion : true,
                    });

                    inicializacionCuenta(result.identificador, resultEmpresa.scope).then(
                        resultInicializacion=>{
                            var database = db.get();
                            var DB = database.db(global.getAuthDatabase());
                            var collection = DB.collection('usuarios');
                            collection.findOneAndUpdate(
                                {_id: new ObjectID(result._id)},
                                {$set: actualizacionCuenta},
                                (err,resultdb)=> {
                                    if (err) {
                                        return res.status(500).json({error: err.message});
                                    }
                                    if (!resultdb.value) {
                                        return res.status(404).json({error: 'no actualizado'});
                                    }
                                    // inicializacionCuenta(result.identificador, resultEmpresa.scope);
                                    return res.status(200).send({mensaje: 'validado correctamente'});
                                });
        
                        }, error=>{
                            return res.status(404).json({error: 'no encontrado'});
                        }
                    );

                } else {
                    return res.status(500).send({mensaje:'codigo incorrecto'});
                }
            } else if (result.validacion === 'validado'){
                    // validacion primera vez cuenta
                    console.log(result.codigoVerificacion , req.body.codigoVerificacion);
                    if (result.codigoVerificacion === req.body.codigoVerificacion) {
    
                        let actualizacionCuenta = {
                            // validacion: 'validado',
                            // validacion: 'validado',
                            // estado: "habilitado",
                            estado: "reestablecido",     /// requiere cambio de contraseña
                            accesos: []
                        } ;
                        // const claveCifrada = await generadorClave(result.codigoVerificacion);
    
                        // if (req.body.device === 'web'){
                        //     actualizacionCuenta.password= claveCifrada;
                        //     actualizacionCuenta.passwordRapida= claveCifrada;
                        // }else if(req.body.device === 'tablet') {
                        //     actualizacionCuenta.password= claveCifrada;
                        //     actualizacionCuenta.passwordRapida= claveCifrada;
                        // } else if (req.body.device === 'movil') {
                        //     actualizacionCuenta.passwordRapida= claveCifrada;
                        //     actualizacionCuenta.password= claveCifrada;
                        // } else {
                        //     return res.status(500).send({mensaje:'error en device'});
                        // }
                        // actualizacionCuenta.accesos.push({
                        //     scope: resultEmpresa.scope,
                        //     habilitacionGeneral: "habilitado",
                        //     habilitaciones:  [],
                        //     permisoInformacion : true,
                        // });
    
                        // inicializacionCuenta(result.identificador, resultEmpresa.scope).then(
                        //     resultInicializacion=>{
                                var database = db.get();
                                var DB = database.db(global.getAuthDatabase());
                                var collection = DB.collection('usuarios');
                                collection.findOneAndUpdate(
                                    {_id: new ObjectID(result._id)},
                                    {$set: actualizacionCuenta},
                                    (err,resultdb)=> {
                                        if (err) {
                                            return res.status(500).json({error: err.message});
                                        }
                                        if (!resultdb.value) {
                                            return res.status(404).json({error: 'no actualizado'});
                                        }
                                        // inicializacionCuenta(result.identificador, resultEmpresa.scope);
                                        return res.status(200).send({mensaje: 'reestablecido correctamente'});
                                    });
            
                            // }, error=>{
                            //     return res.status(404).json({error: 'no encontrado'});
                            // }
                        // );
    
                    } else {
                        return res.status(500).send({mensaje:'codigo incorrecto'});
                    }
            } else {
                return res.status(500).send({mensaje:'validacion incorrecta'});
            }
        }, reason => {
            // si el usuario ya esta registrado entrega el error
            console.log('error', reason);
            return res.status(500).send({mensaje:'error en busqueda'});
        });
    }, error=> {
        return res.status(500).send({message: "error de negocio"});

    })
}


function inicializacionCuenta(usuario, scope){
    console.log('usuario',usuario, scope);
    let body = {
    }

    return new Promise((resolve, reject)=>{
        switch(scope) {
            /////////////////////////////////////////////////////// 'clickgas-platform-users'//////////////////////////////////
            case 'clickgas-platform-users':
                body.usuarioID= usuario
                fetch('http://54.70.216.182:80/clickgas/utilidades/habilitacionCuentaUsuarios', {
                    method: 'patch',
                    body:    JSON.stringify(body),
                    headers: { 'Content-Type': 'application/json' },
                })
                .then(res => res.json())
                .then(json => {

                    console.log(json);
                    resolve(json);
                }, error=> {
                    reject(error);
                });
                break;
            /////////////////////////////////////////////////////// 'clickgas-platform'//////////////////////////////////
            case 'clickgas-platform':
                body.distribuidorID= usuario
                fetch('http://54.70.216.182:80/clickgas/utilidades/habilitacionCuentaDistribuidores', {
                    method: 'patch',
                    body:    JSON.stringify(body),
                    headers: { 'Content-Type': 'application/json' },
                })
                .then(res => res.json())
                .then(json => {

                    console.log(json);
                    resolve(json);
                }, error=> {
                    reject(error);
                });
                break;
            /////////////////////////////////////////////////////// 'clickgas-platform'//////////////////////////////////
            case 'IMS-platform':
                body.distribuidorID= usuario
                // fetch('http://54.70.216.182:80/clickgas/utilidades/habilitacionCuentaDistribuidores', {
                //     method: 'patch',
                //     body:    JSON.stringify(body),
                //     headers: { 'Content-Type': 'application/json' },
                // })
                // .then(res => res.json())
                // .then(json => {

                //     console.log(json);
                //     resolve(json);
                // }, error=> {
                //     reject(error);
                // });
                resolve('ok');
                break;
                case 'uShops-platform':
                    body.distribuidorID= usuario
                    // fetch('http://54.70.216.182:80/clickgas/utilidades/habilitacionCuentaDistribuidores', {
                    //     method: 'patch',
                    //     body:    JSON.stringify(body),
                    //     headers: { 'Content-Type': 'application/json' },
                    // })
                    // .then(res => res.json())
                    // .then(json => {
    
                    //     console.log(json);
                    //     resolve(json);
                    // }, error=> {
                    //     reject(error);
                    // });
                    resolve('ok');
                    break;
                default:
                reject('no encontrado');    
        }


    });

    
}



// if(result.validacion === 'pendiente' || result.validacion === 'temporal' ) {
//     console.log(result.codigoVerificacion , req.body.codigoVerificacion);
//     if (result.codigoVerificacion === req.body.codigoVerificacion) {


//         //////////verificacion de accesos en la cuenta ////////////////////////
//         let acceso = null;
//         result.accesos.forEach(accesoModule =>
//         {
//             if (accesoModule.scope === resultEmpresa.scope)
//             {
//                 acceso = accesoModule;
//             }
//         });




//         let actualizacionCuenta = {
//             validacion: 'validado',
//             estado: "habilitado",
//             accesos: []
//         } ;

//         const claveCifrada = await generadorClave(result.codigoVerificacion);

//         if (req.body.device === 'web'){
//             actualizacionCuenta.password= claveCifrada;
//         }else if(req.body.device === 'tablet') {
//             actualizacionCuenta.password= claveCifrada;

//         } else if (req.body.device === 'movil') {
//             actualizacionCuenta.passwordRapida= claveCifrada;

//         } else {
//             return res.status(500).send({mensaje:'error en device'});
//         }

//         if (acceso === null) {
//             actualizacionCuenta.accesos.push({
//                 scope: resultEmpresa.scope,
//                 habilitacionGeneral: "habilitado",
//                 habilitaciones:  [],
//                 permisoInformacion : true,
//             });
//         }
//         // else {
//         //     return res.status(500).json({error: 'accesos habilitados'});
//         // }

//         var database = db.get();
//         var DB = database.db(global.getAuthDatabase());
//         var collection = DB.collection('usuarios');
//         collection.findOneAndUpdate(
//             {_id: new ObjectID(result._id)},
//             {$set: actualizacionCuenta},
//             (err,result)=> {
//                 if (err) {
//                     return res.status(500).json({error: err.message});
//                 }
//                 if (!result.value) {
//                     return res.status(404).json({error: 'no actualizado'});
//                 }
//                 return res.status(200).send({mensaje: 'validado correctamente'});
//             });
//     } else {
//         return res.status(500).send({mensaje:'codigo incorrecto'});
//     }
// }
// if(result.validacion === 'validado' ) {

//     return res.status(500).send({mensaje:'cuenta validada previamente'});
// }

//////////////////////////////////////////////////////////////////////////////////////////////////////
function verifCodec (req, res){
    let user = req.body;
    console.log(user);


    // verificacion de parametros en mensaje
    if ((req.body.cedula=== undefined) || req.body.scope=== undefined || req.body.device=== undefined || req.body.codigoVerificacion === undefined) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    let busqueda ;

    busqueda = req.body.cedula;
    console.log('busqueda', busqueda);


    _busquedaEmpresa(req.body.scope).then(
        resultEmpresa => {
        _busquedaUsuarioCedula(busqueda).then(resultUser => {
            // si esta libre o en proceso ingresa aqui
            console.log('result', resultUser);

            if(resultUser === null ) {

                return res.status(500).send({mensaje:'cuenta inexistente'});
            }

            if(resultUser.validacion === 'pendiente' ) {
                _busquedaCodigoLibre(req.body.codigoVerificacion).then(
                    resultCodigo=> {

                        console.log('resultCodigo', resultCodigo);

                        return new Promise((resolve, reject) => {

                            if (resultCodigo === null) {

                                reject('codigo inexistente');
                            } else {
                                if (resultCodigo.estado === 'free') {
                                    var database = db.get();
                                    var DB = database.db(global.getAuthDatabase());
                                    var collection = DB.collection('tickets');

                                    collection.findOneAndUpdate(
                                        {_id: new ObjectID(resultCodigo._id)},
                                        {$set: {estado: 'en uso', usuario: resultUser.cedula}},
                                        (err, result) => {
                                            if (err) {
                                                reject('error en usuario');
                                            }
                                            if (!result.value) {
                                                reject('no actualizado');

                                            }
                                            resolve(resultCodigo);
                                        });
                                } else {
                                    reject('codigo en uso');
                                }
                            }
                    });
                    }).then(async resultCodigo => {
                    const claveCifrada = await generadorClave(resultCodigo.codigo);

                    let acceso = null;
                    resultUser.accesos.forEach(accesoModule => {
                        if (accesoModule.scope === req.body.scope) {
                            acceso = accesoModule;
                        }
                    });

                    let actualizacionCuenta = {
                        validacion: 'temporal',
                        // estado: "habilitado",
                        estado: "cambio contraseña",     /// requiere cambio de contraseña
                        accesos: []
                    };

                    if (req.body.device === 'web'){
                        actualizacionCuenta.password= claveCifrada;
                    }else if(req.body.device === 'tablet') {
                        actualizacionCuenta.password= claveCifrada;

                    } else if (req.body.device === 'movil') {
                        actualizacionCuenta.passwordRapida= claveCifrada;

                    } else {
                        return res.status(500).send({mensaje:'error en device'});
                    }

                    


                    if (acceso === null) {
                        actualizacionCuenta.accesos.push({
                            scope: resultEmpresa.scope,
                            habilitacionGeneral: "habilitado",
                            habilitaciones: [],
                            permisoInformacion: true,
                        });
                    }


                    inicializacionCuenta(resultUser.identificador, resultEmpresa.scope).then(
                        resultInicializacion=>{
                        var database = db.get();
                        var DB = database.db(global.getAuthDatabase());
                        var collection = DB.collection('usuarios');
                        collection.findOneAndUpdate(
                            {_id: new ObjectID(resultUser._id)},
                            {$set: actualizacionCuenta},
                            (err, result) => {
                                if (err) {
                                    return res.status(500).json({error: err.message});
                                }
                                if (!result.value) {
                                    return res.status(404).json({error: 'no actualizado'});
                                }
                                return res.status(200).send({mensaje: 'validado correctamente'});
                            });

                        }, error=>{
                            return res.status(404).json({error: 'no encontrado'});
                        }
                    );
                    }).catch(error => {
                            return res.status(500).send({mensaje: error});
                    });
            }
            else if(resultUser.validacion === 'validado' ) {

                return res.status(500).send({mensaje:'cuenta validada previamente'});
            }
            else{
                return res.status(500).send({mensaje:'error de validacion'});
            }
        }
        // , reason => {
        //     // si el usuario ya esta registrado entrega el error
        //     console.log('error', reason);
        //     return res.status(500).send({mensaje:'error en busqueda'});
        // }
        );
    }, error =>{
        return res.status(500).send({mensaje:'error de negocio'});
    });
}


function resetPassword (req, res){

    let user = req.body;
    console.log(user);

    // verificacion de parametros en mensaje
    if ((req.body.email=== undefined) || req.body.device=== undefined  || req.body.scope=== undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    let busqueda ;

    busqueda = req.body.email;
    console.log('busqueda', busqueda);


        
    _busquedaEmpresa(req.body.scope).then(
        resultEmpresa => {
            _busquedaUsuarioSoloEmail(busqueda).then(async resultUsuario => {
            // si esta libre o en proceso ingresa aqui
            console.log('result', resultUsuario);

            if(resultUsuario.validacion !== 'validado' ) {
                return res.status(500).send({mensaje:'cuenta aun no validada'});
            }

            const codigoVerificacion = await (generadorNumeroRandom(5));
            // const claveCifrada = await generadorClave(codigoVerificacion);

            let auxActualizacion = {codigoVerificacion: codigoVerificacion};

            // if (req.body.device === 'web'){
            //     auxActualizacion.password=  claveCifrada;
            //     auxActualizacion.passwordRapida=  claveCifrada;

            // } else if (req.body.device === 'tablet') {
            //     auxActualizacion.password=  claveCifrada;
            //     auxActualizacion.passwordRapida=  claveCifrada;

            // } else if (req.body.device === 'movil') {
            //     auxActualizacion.password=  claveCifrada;
            //     auxActualizacion.passwordRapida=  claveCifrada;

            // } else {
            //     return res.status(500).send({mensaje: "Error en parametros de device"});
            // }

            // auxActualizacion.estado = 'cambio contraseña';

            var database = db.get();
            var DB = database.db(global.getAuthDatabase());
            var collection = DB.collection('usuarios');

            collection.findOneAndUpdate(
                {_id: new ObjectID(resultUsuario._id)},
                {$set:auxActualizacion},
                (err,result)=> {
                    if (err) {
                        return res.status(500).json({error: err.message});
                    }
                    if (!result.value) {
                        return res.status(404).json({error: 'no actualizado'});
                    }


                    ////////////////////////////MODIFICACION KEVIN 1
                    //const fechaActual = new Date();
                    //fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );


                    let promesaGeneral = new Promise((resolve,reject) => {resolve ('start')})
                    promesaGeneral.then(
                        result =>{                                                
                           return inf_usuario (resultUsuario.identificador)
                         },error=>{
                            return  Promise.reject(error)
                         }
                    )
                    .then(
                        inf_usr =>{
                           let message_header_register = "<div style=\"padding: 20px;\"><div style=\"margin: 32px auto; display: flex; flex-direction: row; justify-content: center;\"><div style=\"margin: auto;\"><img  src=\"https://s3-us-west-2.amazonaws.com/pruebas.ushops/logotipo.jpg\" alt=\"\"></div></div><div style=\"margin: 0px auto; border-radius: 5px; border: none; background-color: rgb(237, 250, 248); max-width: 500px; padding: 25px 15px; font-size: 16px;\"><h1 style=\"font-size: 20px; text-align: center;\">Proceso de restauración de contraseña</h1><p style=\"text-align: center; font-size: 16px;\">Con este correo uShops te informa que se ha solicitado un acceso a tu cuenta con una contraseña provisional</p><p style=\"text-align: center; font-size: 14px;\">Una vez ingresado a tu cuenta debes cambiar la contraseña a una nueva para que tu usuario vuelva a estar habilitado</p></div><div style=\"max-width: 500px; margin: 0px auto;\"><p style=\"text-align: center; font-size: 16px;\">Tu contraseña provisional es </p><h1 style=\"text-align: center; letter-spacing: 2px; font-size: 32px; font-weight: bold;\">";
                           let message_body_register = "</h1><p style=\"text-align: center; font-size: 14px;\">Si tienes algún problema escríbenos: services@ushops.tech</p></div></div>";
            
                           let mensaje= ""+message_header_register + inf_usr.codigoVerificacion + message_body_register;
            
                           return enviar_email("uShops - Recuperacion de Clave", inf_usr.email, mensaje)
                        },error=>{
                            return  Promise.reject(error)
                        }
                    )
                    .then(
                        final_result =>{
                            return res.status(200).send({codigoVerificacion: codigoVerificacion});
                        },error=>{
                            return  Promise.reject(error)
                        }
                    )
                    ////////////////////////FIN MODIFICACION KEVIN 1

                
                    //enviocodigoValidacion({identificadorUsuario: resultUsuario.identificador, scope:  resultEmpresa.scope, fechaCreacion: fechaActual});
                    //return res.status(200).send({codigoVerificacion: codigoVerificacion});
                });
                // }
            // });


        }, reason => { 
            // si el usuario ya esta registrado entrega el error
            console.log('error', reason);
            return res.status(500).send({mensaje:'error en busqueda'});
        });
    }, error=>{
        return res.status(500).send({mensaje:'error de negocio'});

    });
}

////////////////////////////MODIFICACION KEVIN 1
function inf_usuario (idUsr){

    var DB =  db.get().db(global.getAdminDatabase()).collection('usuarios');

    let search = { identificador: idUsr };
    let filtro = {projection:{ _id: 0, email:1, codigoVerificacion:1 }};

    const promesa = new Promise((resolve, reject) => {
        DB.findOne(search, filtro, function (err,result) {
            if(err){
                reject ({message:"Error en la peticion"});
            }else{
                resolve (result);
            }
        });
    });
    return promesa;
}

function enviar_email (titulo, mail, mensaje){

    const promesa = new Promise((resolve, reject) => {

        var URL= 'https://api.ushops.tech/EgmSystems/emailing/gmail/sendEmail';
        var request = {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "titulo": titulo,
                "de": "uShops",
                "email":  mail,
                "mensaje": mensaje,
            }),
            cache: 'no-cache'
            
        };

        fetch(URL,request)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            console.log(data)
            resolve ({mensaje: data})
        })
        .catch(function(err) {
            reject (err);
        });    
    })
    return promesa;
}

////////////////////////FIN MODIFICACION KEVIN 1




//////////////////////////////////////////////////////////////////////////////////////////////////////
function createVerifCode (req, res){
    // let user = req.body;
    // console.log(user);


    // // verificacion de parametros en mensaje
    // if ((req.body.cedula=== undefined) || req.body.codigoVerificacion=== undefined || req.body.scope=== undefined ) {
    //     return res.status(500).send({message: "falta parametro de usuario"});
    // }
    //
    let busqueda ;
    //
    busqueda = req.body.cedula;
    console.log('busqueda', req.body);

    _busquedaUsuarioCedula(busqueda).then(async result => {
        // si esta libre o en proceso ingresa aqui
        console.log('result', result);


        // if(result.validacion === 'validado' ) {
        //
        //     return res.status(500).send({mensaje:'cuenta validada previamente'});
        // }

        const codigoVerificacion = await (generadorNumeroRandom(5));
        const fechaActual = new Date();
        fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );

        let ticket = {
            codigo : codigoVerificacion,
            fechaCreacion: fechaActual,
            estado : "free"
        };

        var database = db.get();
        var DB = database.db(global.getAuthDatabase());
        var collection = DB.collection('tickets');

        collection.insertOne(
            ticket,
            (err) => {
                if (err) {
                    return res.status(500).send({mensaje: "Error en la creación del ticket"});
                } else {
                    return res.status(200).send({mensaje: 'ticket creado', ticket: ticket});
                }
            }
        );

    }, reason => {
        // si el usuario ya esta registrado entrega el error
        console.log('error', reason);
        return res.status(500).send({mensaje:'error en busqueda'});
    });
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
function getListTickets (req, res){
    // let user = req.body;
    // console.log(user);


    // // verificacion de parametros en mensaje
    // if ((req.body.cedula=== undefined) || req.body.codigoVerificacion=== undefined || req.body.scope=== undefined ) {
    //     return res.status(500).send({message: "falta parametro de usuario"});
    // }
    //
    let busqueda ;
    //
    busqueda = req.body.cedula;
    // console.log('busqueda', busqueda);

    _busquedaUsuarioCedula(busqueda).then(async result => {
        // si esta libre o en proceso ingresa aqui
        console.log('result', result);



        var database = db.get();
        var DB = database.db(global.getAuthDatabase());
        var collection = DB.collection('tickets');

        let search ={};
        let parametros = {projection:{
                codigo:1,
                estado:1,
            }};

        collection.find(search, parametros).toArray(function (err,result) {
            // console.log(result);
            if(err){
                res.status(500).send({message:"Error en la peticion de los tickets"});
            }else{
                if(!result){
                    res.status(404).send({message:"No existen tickets"});
                }else{
                    res.status(200).send(result);
                }
            }
        });

    }, reason => {
        // si el usuario ya esta registrado entrega el error
        console.log('error', reason);
        return res.status(500).send({mensaje:'error en busqueda'});
    });
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function _busquedaIdentificadorLibre(identificador){

    var search ={$or: [{identificador :identificador}]};
    // var search ={ruc :ruc};

    console.log(search);
    // console.log(usuario);
    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

    const promesa = new Promise((resolve, reject) => {
        collection.find(search).toArray(function (err, result) {
            if (err) {
                resolve (null);
            } else {
                console.log('busqueda', result);
                if (result.length === 0) {
                    resolve ('free');
                } else {
                    resolve ('registered');
                }
            }
        });
    });
    return promesa;
}






function _busquedaUsuario(parametro){

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

    var search= {$or: [{identificador: parametro},{email: parametro},{username: parametro}]};


    const promesa = new Promise((resolve, reject) => {
            collection.findOne(search, function (err,result) {
                if(err){
                    reject({mensaje:"Error en la peticion del usuario"});
                }
                console.log('busqueda', result);
                resolve(result);
            });
    });
    return promesa;
}
function _busquedaUsuarioSoloEmail(parametro){

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

    var search= {$or: [{email: parametro}]};


    const promesa = new Promise((resolve, reject) => {
            collection.findOne(search, function (err,result) {
                if(err){
                    reject({mensaje:"Error en la peticion del usuario"});
                }
                console.log('busqueda', result);
                if (result === null){
                    reject({mensaje:"Error en el usuario"});
                }else 
                {
                    resolve(result);
                }
            });
    });
    return promesa;
}


function _busquedaCodigoLibre(codigo){

    var search ={$or: [{codigo :codigo}]};
    // var search ={ruc :ruc};

    console.log(search);
    // console.log(usuario);
    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('tickets');

    const promesa = new Promise((resolve, reject) => {
        collection.findOne(search, function (err, result) {
            if (err) {
                resolve (null);
            } else {

                console.log('busqueda', result);
                resolve(result);
                // if (result !== null) {
                //     resolve(result);
                // } else {
                //     reject('no encontrado');
                // }
            }
        });
    });
    return promesa;
}


function _busquedaEmpresa(parametro){


    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('empresas');

    var search= {scope: parametro};
    console.log(search);


    const promesa = new Promise((resolve, reject) => {
            collection.findOne(search, function (err,result) {
                if(err){
                    reject({mensaje:"Error en la peticion de la empresa"});
                }
                console.log('busqueda empresas', result);
                if(result === null){
                    reject({mensaje:"Error en la peticion de la empresa"});
                }
                resolve(result);
            });
    });
    return promesa;
}


////
async function _registroUsuario(resultCodigo, resultUser) {


}

function _actualizacionUsuario(resultCodigo) {

}



function _busquedaUsuarioModules(parametro, scope){

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

    var search= {$and: [
        {$or: [{identificador: parametro},{cedula: parametro},{email: parametro},{username: parametro}]},
        {accesos: {$elemMatch: {scope: scope}}}
    ]};
    
    let parametros = {projection:{

            accesos:{ $elemMatch: { scope: scope } },
            // nombres:1,
            // apellidos:1,
            // passwordRapida:1,
            // accesos:1,
            // estado:1,
            // validacion:1,
        }};

    const promesa = new Promise((resolve, reject) => {
            collection.findOne(search, parametros, function (err,result) {
                if(err){
                    reject({mensaje:"Error en la peticion del usuario"});
                }else{
                    console.log('busqueda', result);
                    if(!result){
                        reject({mensaje:"error"});
                    }else{
                        resolve(result.accesos[0]);
                    }
                }
            });
    });
    return promesa;
}



////////////////////////////////////////////////////////////////funciones de utilidad //////////////////////////////////

function generadorNumeroRandom (digitos){
    let caracteres = "0123456789";
    let identificador = "";
    let i;
    for (i=0; i<digitos; i++) identificador +=caracteres.charAt(Math.floor(Math.random()*caracteres.length));

    return identificador;
}

function generadorClave(clave){
    var salt = bcrypt.genSaltSync(13);
    var hasht;

    const promesa = new Promise((resolve, reject) => {
        bcrypt.hash(clave, salt, function(err, hash){
            if(err) throw err;

            bcrypt.compare(clave, hash, function(err, result) {
                if (err) {
                    throw (err);
                }
                console.log(result);
                hasht = hash;
                resolve(hasht);
            });
        });

    });
    return promesa;

}



module.exports = {
    status,

    administracionRegistro,

    verificacionRegistro,
    getVerifCode,
    resetPassword
    // verifCodec,

    // createVerifCode,
    // getListTickets
};

