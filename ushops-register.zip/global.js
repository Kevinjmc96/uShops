
const fs=require('fs'),path=require('path');
const jwt = require('jsonwebtoken');
var conexion;

module.exports={
    // DB_CONN:'mongodb://egmAdmin:passEgm123@10.0.1.45:49850/admin',
    // DB_CONN:'mongodb://127.0.0.1',
    JWT_SECRET:     'xLoxOhuIcYBTzOWYGctsCFnU9gA6SUW5XELkdKzYn6Do0F5sOIhzCU2hR9X2ozr',
    JWT_FAST:       'xLoxOhuIcDSFDFZSDFSDFG  df5XELkdKzYn6Do0F5sOIhzCU2hR9X2ozr',
    JWT_CLICKGAS:   'xdkdsfgu894n3kl539oAcasfdasASDF543@4f23d@#$D432d@#hzCU2hR9X2ozr',

//    privatekey:fs.readFileSync(path.join(__dirname,'key.pem')),
//    certificate:fs.readFileSync(path.join(__dirname,'cert.pem')),

    getIDclient:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).IDclient;
    },

    getDB:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).db;
    },
    getPort:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).port;
    },
    getUsername:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).user;
    },
    getNegocio:function(headers) {
        let token = headers.authorization.split(' ')[1];
        console.log('token',jwt.decode(token, this.JWT_SECRET));
        return jwt.decode(token, this.JWT_SECRET).negocio;
    },
    getHabilitaciones:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).habilitaciones;
    },
    getToken:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return token;
    },

    setConexion:function(conection){
        conexion = conection;
        return;
    },
    getAuthDatabase:function() {
        return 'AdministracionUshops';
    },
};
