'use strict'

var global = require('../global');
// const jwt = require('jsonwebtoken');
// var moment = require('moment');
// var secret = "ims-systems-clave-unica";
// var secret = "xLoxOhuIcYBTzOWYGctsCFnU9gA6SUW5XELkdKzYn6Do0F7sOIhzCU2hR9X2ozr";



function getModuleAutorization(module, parameter){

    if (module.indexOf(parameter)===-1)
    {
        return false;
    }
    return true;
}


module.exports = {
    getModuleAutorization,

};
