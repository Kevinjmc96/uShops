'use strict'



var express = require('express');
var RegistroController = require('../controllers/registro');
var router = express.Router();

// var multipart = require('connect-multiparty');

// var md_auth = require('../middleware/authenticated');

    router.get('/status', RegistroController.status);

    // router.get('/facturacion/getAllBills', FacturacionController.getAllBills);

    // router.patch('/autenticacion/auth', AutenticacionController.auth);
    router.patch('/newUsr', RegistroController.administracionRegistro);
    // router.patch('/newUsrMob', RegistroController.administracionRegistroMob);
    router.patch('/verifUsr', RegistroController.verificacionRegistro);
    router.patch('/getVerifCode', RegistroController.getVerifCode);

    router.patch('/resetPassword', RegistroController.resetPassword);

    // router.patch('/verifCodec', RegistroController.verifCodec);
    // router.patch('/createVerifCode', RegistroController.createVerifCode);
    // router.patch('/getListTickets', RegistroController.getListTickets);

// router.patch('/getUsrIm', AutenticacionController.administracionAuthIm);
    // router.patch('/autenticacion/getNegocios', NegocioController.getNegocios);
    // router.put('/facturacion/updateBill', FacturacionController.updateBill);


    // router.get('/facturacion/getTotalBills', FacturacionController.getTotalBills);

    // router.get('/facturacion/getBillsByDate', FacturacionController.getBillsByDate);





module.exports = router;







